import requests

def get_phone_info(phone_number, api_key):
    url = f'https://api.callerapi.com/v1/phone/{phone_number}'
    headers = {
        'Authorization': f'Bearer {api_key}'
    }

    response = requests.get(url, headers=headers)

    if response.status_code == 200:
        return response.json()
    else:
        print(f"Ошибка: {response.status_code} - {response.text}")
        return None

def main():
    phone_number = input("Введите номер телефона (в формате +79111234567): ")
    api_key = '709f3eab-35e6-435d-aedc-a25af99aec21'  # Замените на Ваш API-ключ

    phone_info = get_phone_info(phone_number, api_key)

    if phone_info:
        print("Информация о номере телефона:")
        print(phone_info)

if __name__ == "__main__":
    main()